## Welcome !
<br><br>
<i> Biodiversity in Zimbabwe National Parks</i> is an app that let you visualize the distribution of species in the different national parks across Zimbabwe.
From the left navigation panel you'll be able to access the maps, data and charts concerning the Zimbabwe National Parks and their resident species.

It has been made with r-shiny 

For a quick walkthrough of one of the parks, have a look a the video below.
<br><br><br>
<iframe style = "display: block; margin: auto;" width="640" height="360" src="https://www.youtube.com/embed/SZ2yHb8ukcg?hd=1"></iframe>
