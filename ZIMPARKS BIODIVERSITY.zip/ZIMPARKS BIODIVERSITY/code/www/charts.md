### Species Ggplot2 Charts

In this section you can view a couple of barcharts with the the total number of species per category for every park.
<br><br><br>
