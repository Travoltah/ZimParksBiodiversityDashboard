### Species Choropleth map

In this section you can view a choropleth map of the species count per category. A recap table per state is rendered for comparing purposes.
<br><br><br>
